<?php

    function search($login_result, $url, $getData){
    $session_id = $login_result->id;

      //The name of the module
       $search_by_module_parameters = array(  
        "session" => $session_id,  
        'search_string' => $getData,  
        'modules' => array(  
          'Accounts',  
          ),        'offset' => 0,  
        'max_results' => 2,  
        'assigned_user_id' => '',  
        'select_fields' => array('id','name'),  
        'unified_search_only' => false,  
        'favorites' => false  
        );  

        $search_by_module_results = call('search_by_module', $search_by_module_parameters, $url);  
        $id = $search_by_module_results->entry_list['0']->records['0'] ;
        
        
            if ($search_by_module_results) {
              $id = $search_by_module_results->entry_list['0']->records['0']->id->value;
              $name = $search_by_module_results->entry_list['0']->records['0']->name->value;
            //   die(var_dump($search_by_module_results));
              $update = UpdateOrderPaystatus($login_result, $url,  $id);
              if ($update) {
               return true;
              }
            }
    }

    function UpdateOrderPaystatus($login_result, $url,  $id){
              
       $session_id = $login_result->id;

    $set_entry_parameters = array(
      //session id
      "session" => $session_id,

      //The name of the module
      "module_name" => "Accounts",

      //Record attributes
      "name_value_list" => array(
        array("name" => "id", "value" => $id ),
        array("name" => "payment_status", "value" => "Paid" )

        ),
      );
    $set_entry_result = call("set_entry", $set_entry_parameters, $url);
    // var_dump($set_entry_result->id);die();
    $id = $set_entry_result->id;
    if ($set_entry_result) {
      return true;
    }
    }

    function saveOrder($login_result, $url,  $order){

        $session_id = $login_result->id;
        

        if($order->payment_method == "bacs"){
            $payment_method = "Bank Transfer";
        }else{
        $payment_method = ($order->payment_method == "cod") ? "Pay On Delivery": "Card Payment";
        }
        if($order->payment_method == "bacs"){
        $payment_status = "Pending";
        }else{
        $payment_status = ($order->payment_method == "cod") ? "Pending": "Paid";
        }
        
    // Check if order has multiple Items
        // $searchString = ',';
        // if( strpos($searchString, $order->item_sku) !== false ) {
        $item_sku = (explode(",", $order->item_sku));
        $item_qty = (explode(",", $order->quantity));
        $item_price = (explode(",", $order->item_price));
        
    //   Search for Copper Chef Pan
        if (in_array('STV540301', $item_sku)) {
        $key = array_search('STV540301', $item_sku);
        $chefprice  = $item_price[$key];
        $chefqty    = $item_qty[$key];
        }
        
    //   Search for Simply Fit
        if (in_array('STV540308', $item_sku)) {
        $key = array_search('STV540308', $item_sku);
        $s_fitqty    = $item_qty[$key];
        }
        
    //   Search for Arctic Air
        if (in_array('STV540306', $item_sku)) {
        $key = array_search('STV540306', $item_sku);
        $a_airqty    = $item_qty[$key];
        }
        
    //   Search for Turbo Pump
        if (in_array('STV540307', $item_sku)) {
        $key = array_search('STV540307', $item_sku);
        $t_pumpqty    = $item_qty[$key];
        }
       
    //   Search for My Fit
        if (in_array('STV540305', $item_sku)) {
        $key = array_search('STV540305', $item_sku);
        $m_fitqty    = $item_qty[$key];
        }
        
    //   Search for Upsell Copper Chef Pan Group 7500
        if (in_array('STV540304', $item_sku)) {
        $key = array_search('STV540304', $item_sku);
        $upsellprice  = $item_price[$key];
        $upsellqty1    = $item_qty[$key];
        $upsellname    = 'CopperChefPan_UpsellFryingPan';
        }
            
    //   Search for Upsell Copper Chef Pan Group 7500
        if (in_array('STV540300', $item_sku)) {
        $key = array_search('STV540300', $item_sku);
        $chefqty    = $item_qty[$key];
        $upsellqty2    = $item_qty[$key];
        $new_combo_qty = $item_qty[$key];
        $upsellname    = 'CopperChefPan_UpsellFryingPan';
        }
        
    //   Search for Upsell Copper Chef Pan 22000
        if (in_array('STV540302', $item_sku)) {
        $key = array_search('STV540302', $item_sku);
        $upsellprice  = $item_price[$key];
        $upsellqty2    = $item_qty[$key];
        $upsellname    = 'CopperChefPan_UpsellFryingPan';
        }
        else{
        $upsellprice  = "";
        $upsellqty    = "";
        $upsellname   = "";
        }

    //   Search for slim_jeggings
        if (in_array('STV540317', $item_sku)) {
        $key = array_search('STV540317', $item_sku);
        $slim_jeggings_qty    = $item_qty[$key];
        }
    //   Search for velform_mini
        if (in_array('STV540316', $item_sku)) {
        $key = array_search('STV540316', $item_sku);
        $velform_mini_qty    = $item_qty[$key];
        }
    //   Search for comfortisse_bra
        if (in_array('STV540315', $item_sku)) {
        $key = array_search('STV540315', $item_sku);
        $comfortisse_bra_qty    = $item_qty[$key];
        }
    //   Search for polaryte_unglasses
        if (in_array('STV540314', $item_sku)) {
        $key = array_search('STV540314', $item_sku);
        $polaryte_unglasses_qty    = $item_qty[$key];
        }
    //   Search for starlyf_cam
        if (in_array('STV540313', $item_sku)) {
        $key = array_search('STV540313', $item_sku);
        $starlyf_cam_qty    = $item_qty[$key];
        }
    //   Search for insta_life
        if (in_array('STV540312', $item_sku)) {
        $key = array_search('STV540312', $item_sku);
        $insta_life_qty    = $item_qty[$key];
        }
    //   Search for starlyf_broom
        if (in_array('STV540311', $item_sku)) {
        $key = array_search('STV540311', $item_sku);
        $starlyf_broom_qty    = $item_qty[$key];
        }
    //   Search for gymform_abs
        if (in_array('STV540310', $item_sku)) {
        $key = array_search('STV540310', $item_sku);
        $gymform_abs_qty    = $item_qty[$key];
        }
        
        
        
        
        // $new_price = ($chefprice != "")  ? $chefprice : "0" ;
        $new_qty = ($chefqty != "" ) ? $chefqty : 0;
        
        $ufp_price  = ($new_combo_qty <= 1 ) ? "7500" : "22000";
        // $ufp_price_remove_pan  = ($new_qty < 1 ) ? "22000" : "7500";
        
        // Get Price for removing Upsell
        // if($new_qty < 1){
        //     $remove_upsell_price = $upsellqty1 * 7500;
        //     $remove_total = $order->total - $remove_upsell_price;
        //     $single_upsell_price = $upsellqty1 * 22000;
        //     $order->total = $remove_total + $single_upsell_price;
        // }
        

        
        // $new_upsellqty1 = ($upsellqty1 != "")  ? $upsellqty1 : $upsellqty2 ;
        // $new_upsellqty2 = ($upsellqty2 != "" ) ? $upsellqty2 : "0";
        // if($new_upsellqty1 != ""){
        //     $upsell_qty = $new_upsellqty1;
        // }elseif($new_upsellqty2 != ""){
        //     $upsell_qty = $new_upsellqty2;
        // }
        // $upsellname = ($new_upsellqty != "" ) ? 'CopperChefPan_UpsellFryingPan' : "";
        
        // var_dump($new_upsellqty1);die();

    $set_entry_parameters = array(
      //session id
      "session" => $session_id,

      //The name of the module
      "module_name" => "Contacts",

      //Record attributes
      "name_value_list" => array(
        array("name" => "first_name", "value" => $order->bill_firstname ),
        array("name" => "last_name", "value" => $order->bill_surname ),
        array("name" => "phone_mobile", "value" => $order->customer_phone ),
        array("name" => "email1", "value" => $order->customer_email ),
        array("name" => "description", "value" => $order->transaction_key ),
        array("name" => "ufp_price", "value" => $ufp_price ),
        
         array("name" => "ccp_qty", "value" => $new_qty ),
         array("name" => "ufp_qty", "value" => $upsellqty2 ),
         array("name" => "fit_jen", "value" => $m_fitqty ),
         array("name" => "simply_fit", "value" => $s_fitqty ),
         array("name" => "turbo_pump", "value" => $t_pumpqty ),
         array("name" => "artic_air", "value" => $a_airqty ),
         
         array("name" => "slim_jeggings", "value" => $slim_jeggings_qty ),
         array("name" => "velform_mini", "value" => $velform_mini_qty ),
         array("name" => "comfortisse_bra", "value" => $comfortisse_bra_qty ),
         array("name" => "polaryte_sunglasses", "value" => $polaryte_unglasses_qty ),
         array("name" => "starlyf_cam", "value" => $starlyf_cam_qty ),
         array("name" => "insta_life", "value" => $insta_life_qty ),
         array("name" => "starlyf_broom", "value" => $starlyf_broom_qty ),
         array("name" => "gymform_abs", "value" => $gymform_abs_qty ),
         
         
        array("name" => "total_amount", "value" => $order->total ),
        array("name" => "deliverycharge", "value" => $order->shipping_cost ),
        array("name" => "primary_address_street", "value" => $order->bill_address1." ".$order->bill_address2 ),
        array("name" => "primary_address_city", "value" => $order->bill_city ),
        array("name" => "primary_address_state", "value" => $order->ship_state ),
        // array("name" => "lgas", "value" => $order->bill_city ),
        array("name" => "del_state", "value" => $order->ship_state ),
        array("name" => "primary_address_postalcode", "value" => $order->ship_zip ),
        array("name" => "primary_address_country", "value" => "NG" ),
        array("name" => "tv_channels", "value" => "Website" ),
        array("name" => "pay_method", "value" => $payment_method),
        // Pending
        array("name" => "payment_status", "value" => $payment_status ),

        ),
      );
    $set_entry_result = call("set_entry", $set_entry_parameters, $url);
    $id = $set_entry_result->id;
    if ($set_entry_result) {
    //   var_dump($set_entry_result);
      return true;
    }
    }

    // string contianing a GUID in the format: aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee

    function ensure_length(&$string, $length)
      {
          $strlen = strlen($string);
          if ($strlen < $length) {
              $string = str_pad($string, $length, '0');
          } elseif ($strlen > $length) {
              $string = substr($string, 0, $length);
          }
      }

    function create_guid()
      {
          $microTime = microtime();
          list($a_dec, $a_sec) = explode(' ', $microTime);

          $dec_hex = dechex($a_dec * 1000000);
          $sec_hex = dechex($a_sec);

          ensure_length($dec_hex, 5);
          ensure_length($sec_hex, 6);

          $guid = '';
          $guid .= $dec_hex;
          $guid .= create_guid_section(3);
          $guid .= '-';
          $guid .= create_guid_section(4);
          $guid .= '-';
          $guid .= create_guid_section(4);
          $guid .= '-';
          $guid .= create_guid_section(4);
          $guid .= '-';
          $guid .= $sec_hex;
          $guid .= create_guid_section(6);

          return $guid;
      }

    function create_guid_section($characters)
        {
            $return = '';
            for ($i = 0; $i < $characters; ++$i) {
                $return .= dechex(mt_rand(0, 15));
            }

            return $return;
        }
  // Unique ID ends here...

?>