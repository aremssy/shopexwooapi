<?php

    function search($login_result, $url, $getData){
    $session_id = $login_result->id;

      //The name of the module
       $search_by_module_parameters = array(  
        "session" => $session_id,  
        'search_string' => $getData,  
        'modules' => array(  
          'Accounts',  
          ),        'offset' => 0,  
        'max_results' => 2,  
        'assigned_user_id' => '',  
        'select_fields' => array('id','name'),  
        'unified_search_only' => false,  
        'favorites' => false  
        );  

        $search_by_module_results = call('search_by_module', $search_by_module_parameters, $url);  
        $id = $search_by_module_results->entry_list['0']->records['0'] ;
        
        
            if ($search_by_module_results) {
              $id = $search_by_module_results->entry_list['0']->records['0']->id->value;
              $name = $search_by_module_results->entry_list['0']->records['0']->name->value;
            //   die(var_dump($search_by_module_results));
              $update = UpdateOrderPaystatus($login_result, $url,  $id);
              if ($update) {
               return true;
              }
            }
    }

    function UpdateOrderPaystatus($login_result, $url,  $id){
              
       $session_id = $login_result->id;

    $set_entry_parameters = array(
      //session id
      "session" => $session_id,

      //The name of the module
      "module_name" => "Accounts",

      //Record attributes
      "name_value_list" => array(
        array("name" => "id", "value" => $id ),
        array("name" => "payment_status", "value" => "Paid" )

        ),
      );
    $set_entry_result = call("set_entry", $set_entry_parameters, $url);
    // var_dump($set_entry_result->id);die();
    $id = $set_entry_result->id;
    if ($set_entry_result) {
      return true;
    }
    }

    function saveOrder($login_result, $url,  $order){

        $session_id = $login_result->id;
        

        if($order->payment_method == "bacs"){
            $payment_method = "Bank Transfer";
        }else{
        $payment_method = ($order->payment_method == "cod") ? "Pay On Delivery": "Card Payment";
        }
        if($order->payment_method == "bacs"){
        $payment_status = "NotPaid";
        }else{
        $payment_status = ($order->payment_method == "cod") ? "PayOnDelivery": "Paid";
        }
        
    // Check if order has multiple Items
        // $searchString = ',';
        // if( strpos($searchString, $order->item_sku) !== false ) {
        $item_sku = (explode(",", $order->item_sku));
        $item_qty = (explode(",", $order->quantity));
        $item_price = (explode(",", $order->item_price));
        
    //   Search for Copper Chef Pan
        if (in_array('STV540301', $item_sku)) {
        $key = array_search('STV540301', $item_sku);
        $chefprice  = $item_price[$key];
        $chefqty    = $item_qty[$key];
        }
        
    //   Search for Upsell Copper Chef Pan Group
        if (in_array('STV540304', $item_sku)) {
        $key = array_search('STV540304', $item_sku);
        $upsellprice  = $item_price[$key];
        $upsellqty    = $item_qty[$key];
        $upsellname    = 'CopperChefPan_UpsellFryingPan';
        }
        
    //   Search for Upsell Copper Chef Pan
        if (in_array('STV540302', $item_sku)) {
        $key = array_search('STV540302', $item_sku);
        $upsellprice  = $item_price[$key];
        $upsellqty    = $item_qty[$key];
        $upsellname    = 'CopperChefPan_UpsellFryingPan';
        }else{
        $upsellprice  = "";
        $upsellqty    = "";
        $upsellname   = "";
        }
        // }
        // else{
        // $item_sku = $order->item_sku;
        
        //   Search for Upsell Copper Chef Pan
        // if ($item_sku == 'STV540302' || $item_sku == 'STV540304' ) {
        // $upsellprice  = $order->item_price;
        // $upsellqty    = $order->quantity;
        // $upsellname    = 'CopperChefPan_UpsellFryingPan';
        // }
        // elseif($item_sku == 'STV5403021'){  
        // $chefprice  = $order->item_price;
        // $chefqty    = $order->quantity;
        // }
        // }  
        $new_price = ($chefprice != "")  ? $chefprice : $order->item_price ;
        $new_qty = ($chefqty != "" ) ? $chefqty : $order->quantity;
        $new_upsellprice = ($upsellprice != "")  ? $upsellprice : "" ;
        $new_upsellqty = ($upsellqty != "" ) ? $upsellqty : "0";
        $upsellname = ($new_upsellqty != "" ) ? 'CopperChefPan_UpsellFryingPan' : "";
        

    $set_entry_parameters = array(
      //session id
      "session" => $session_id,

      //The name of the module
      "module_name" => "Accounts",

      //Record attributes
      "name_value_list" => array(
        array("name" => "name", "value" => $order->bill_firstname. " ".$order->bill_surname ),
        array("name" => "phone_office", "value" => $order->customer_phone ),
        array("name" => "email1", "value" => $order->customer_email ),
        array("name" => "description", "value" => $order->transaction_key. " \n Products: ". $order->item_name. " \n Quantities: ". $order->quantity. " \n Total: ". $order->total . " \n Shipping: ". $order->shipping_cost ),
        
         array("name" => "product_of_interest", "value" => "CopperChefPan" ),
         array("name" => "quantity", "value" => $new_qty ),
         
         array("name" => "upsell_products", "value" => $upsellname ),
         array("name" => "quantityupsell", "value" => $new_upsellqty ),
         array("name" => "ccpan_upsell", "value" => $new_upsellprice ),
         
        array("name" => "price", "value" => $order->total ),
        array("name" => "deliverycharge", "value" => $order->shipping_cost ),
        array("name" => "billing_address_street", "value" => $order->bill_address1." ".$order->bill_address2 ),
        array("name" => "billing_address_city", "value" => $order->bill_city ),
        array("name" => "billing_address_state", "value" => $order->ship_state ),
        array("name" => "lgas", "value" => $order->bill_city ),
        array("name" => "states", "value" => $order->ship_state ),
        array("name" => "billing_address_postalcode", "value" => $order->ship_zip ),
        array("name" => "billing_address_country", "value" => "NG" ),
        array("name" => "tv_channels", "value" => "Website" ),
        array("name" => "mode_of_payment", "value" => $payment_method),
        array("name" => "payment_status", "value" => $payment_status ),

        ),
      );
    $set_entry_result = call("set_entry", $set_entry_parameters, $url);
    $id = $set_entry_result->id;
    if ($set_entry_result) {
    //   var_dump($id);
      return true;
    }
    }

    // string contianing a GUID in the format: aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee

    function ensure_length(&$string, $length)
      {
          $strlen = strlen($string);
          if ($strlen < $length) {
              $string = str_pad($string, $length, '0');
          } elseif ($strlen > $length) {
              $string = substr($string, 0, $length);
          }
      }

    function create_guid()
      {
          $microTime = microtime();
          list($a_dec, $a_sec) = explode(' ', $microTime);

          $dec_hex = dechex($a_dec * 1000000);
          $sec_hex = dechex($a_sec);

          ensure_length($dec_hex, 5);
          ensure_length($sec_hex, 6);

          $guid = '';
          $guid .= $dec_hex;
          $guid .= create_guid_section(3);
          $guid .= '-';
          $guid .= create_guid_section(4);
          $guid .= '-';
          $guid .= create_guid_section(4);
          $guid .= '-';
          $guid .= create_guid_section(4);
          $guid .= '-';
          $guid .= $sec_hex;
          $guid .= create_guid_section(6);

          return $guid;
      }

    function create_guid_section($characters)
        {
            $return = '';
            for ($i = 0; $i < $characters; ++$i) {
                $return .= dechex(mt_rand(0, 15));
            }

            return $return;
        }
  // Unique ID ends here...

?>