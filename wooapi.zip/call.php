<?php
require_once('auth.php');
require_once('functions.php');

  $order   =  new ArrayObject($_POST,ArrayObject::ARRAY_AS_PROPS);
  if (isset($_POST['apiuser'])) {
  $savereq = saveOrder($login_result, $url, $order);
    return true;
  }
  elseif (isset($_GET['PayUReference'])) {
  $ref = $_GET['PayUReference'];
//   echo $ref; die();
  $req = search($login_result, $url, $ref);
    return $req;
  }
  
  


?>